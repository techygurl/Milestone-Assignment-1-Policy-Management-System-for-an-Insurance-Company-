#!/usr/bin/env python
# coding: utf-8

# In[8]:


class Product:
    def __init__(self, product_id, name, premium):
        self.product_id = product_id
        self.name = name
        self.premium = premium
        self.active = True

    def update_product(self, name=None, premium=None):
        if name:
            self.name = name
        if premium:
            self.premium = premium

    def suspend_product(self):
        self.active = False

