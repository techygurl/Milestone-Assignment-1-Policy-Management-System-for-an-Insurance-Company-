#!/usr/bin/env python
# coding: utf-8

# In[2]:


from datetime import datetime

class Payment:
    def __init__(self, amount):
        self.amount = amount
        self.date = datetime.now()

    @staticmethod
    def send_reminder(policyholder):
        print(f"Reminder: {policyholder.name}, your payment is due.")

    @staticmethod
    def apply_penalty(policyholder):
        print(f"Penalty applied to {policyholder.name} for late payment.")

