#!/usr/bin/env python
# coding: utf-8

# In[4]:


class Policyholder:
    def __init__(self, policyholder_id, name):
        self.policyholder_id = policyholder_id
        self.name = name
        self.active = True
        self.policies = []
        self.payments = []

    def register_policy(self, product):
        if product.active:
            self.policies.append(product)
        else:
            print(f"Cannot register to inactive product: {product.name}")

    def suspend(self):
        self.active = False

    def reactivate(self):
        self.active = True

    def add_payment(self, payment):
        self.payments.append(payment)

    def display_account_details(self):
        print(f"\nPolicyholder: {self.name}")
        print(f"Status: {'Active' if self.active else 'Suspended'}")
        print("Policies:")
        for product in self.policies:
            print(f"  - {product.name} (Premium: {product.premium})")
        print("Payments:")
        for payment in self.payments:
            print(f"  - {payment.amount} on {payment.date.strftime('%Y-%m-%d')}")


# In[5]:


from product import Product
from policyholder import Policyholder
from payment import Payment

# Create products
product1 = Product(1, "Health Insurance", 300)
product2 = Product(2, "Car Insurance", 450)

# Create policyholders
peace = Policyholder(201, "Peace")
joyce = Policyholder(202, "Joyce")

# Register policies
peace.register_policy(product1)
joyce.register_policy(product2)

# Process payments
payment1 = Payment(product1.premium)
payment2 = Payment(product2.premium)

peace.add_payment(payment1)
joyce.add_payment(payment2)

# Display account details
print("\n--- Policyholder Account Details ---")
peace.display_account_details()
joyce.display_account_details()

